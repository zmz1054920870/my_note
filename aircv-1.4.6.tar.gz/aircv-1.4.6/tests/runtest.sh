#! /bin/sh
#
# runtest.sh
# Copyright (C) 2016 hzsunshx <hzsunshx@onlinegame-14-51>
#
# Distributed under terms of the MIT license.
#


echo "Just skip test."
